from datetime import datetime
import yaml
from src.packet_capture.capture import start_capture

def load_config():
    with open("configs/config.yaml", "r") as f:
        return yaml.safe_load(f)

def banner():
    print("=" * 60)
    print(" AI-POWERED SOC : INTRUSION DETECTION SYSTEM ")
    print(" Version 1.0")
    print("=" * 60)

def start_system(config):
    print(f"[+] Project Name : {config['project']['name']}")
    print(f"[+] Version      : {config['project']['version']}")
    print(f"[+] Start Time   : {datetime.now()}")
    print("\n[+] SOC System Initialized Successfully")
    print("\n[+] Launching Packet Capture Module...")
    start_capture()

if __name__ == "__main__":
    banner()
    config = load_config()
    start_system(config)
