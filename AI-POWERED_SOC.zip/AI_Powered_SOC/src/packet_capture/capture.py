from datetime import datetime
import time
from scapy.all import sniff, IP, TCP, UDP

from src.intrusion_detection.model_predict import predict_packet
from src.alerts.notifier import send_critical_alert
from src.utils.firewall import block_ip
from src.utils.db import init_db, insert_event
from src.correlation.engine import correlate_event

# ==============================
# WEBSOCKET (OPTIONAL)
# ==============================
try:
    from dashboard.socket_app import broadcast_new_event
    SOCKET_ENABLED = True
except Exception:
    SOCKET_ENABLED = False

# ==============================
# INIT DATABASE
# ==============================
init_db()

# ==============================
# MAIN PACKET HANDLER
# ==============================
def process_packet(packet):
    if IP not in packet:
        return

    # ------------------------------
    # 1️⃣ ML PREDICTION
    # ------------------------------
    try:
        result = predict_packet(packet)
    except Exception as e:
        print("[ML ERROR]", e)
        return

    src_ip = result.get("src_ip")
    attack = result.get("attack", "Unknown")
    severity = result.get("severity", "LOW")

    # ------------------------------
    # 2️⃣ PROTOCOL INFO
    # ------------------------------
    protocol = "OTHER"
    dst_port = None

    if TCP in packet:
        protocol = "TCP"
        dst_port = packet[TCP].dport
    elif UDP in packet:
        protocol = "UDP"
        dst_port = packet[UDP].dport

    # ------------------------------
    # 3️⃣ BUILD EVENT
    # ------------------------------
    event = {
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "src_ip": src_ip,
        "attack": attack,
        "severity": severity,
        "protocol": protocol,
        "dst_port": dst_port,
        "verdict": "NORMAL",
        "response": None,
        "correlation_reason": None
    }

    # ------------------------------
    # 4️⃣ 🔥 CORRELATION ENGINE (FINAL)
    # ------------------------------
    final_severity, reason = correlate_event(event)
    event["severity"] = final_severity
    event["correlation_reason"] = reason

    if final_severity in ("HIGH", "CRITICAL"):
        event["verdict"] = "ATTACK"

    # ------------------------------
    # 5️⃣ 🔥 AUTO RESPONSE (CRITICAL ONLY)
    # ------------------------------
    if final_severity == "CRITICAL":
        try:
            method = block_ip(src_ip)
            event["response"] = f"BLOCKED ({method})"
        except Exception as e:
            event["response"] = "BLOCK FAILED"
            print("[FIREWALL ERROR]", e)

        # 🔔 ALERT (EMAIL + TELEGRAM)
        send_critical_alert(
            src_ip=src_ip,
            attack_type=f"{attack} (correlated)",
            severity=final_severity
        )

    # ------------------------------
    # 6️⃣ LOG EVENT TO DB
    # ------------------------------
    insert_event(event)

    # ------------------------------
    # 7️⃣ REAL-TIME DASHBOARD UPDATE
    # ------------------------------
    if SOCKET_ENABLED:
        try:
            broadcast_new_event(event)
        except Exception:
            pass

    # ------------------------------
    # 8️⃣ CONSOLE OUTPUT (SOC STYLE)
    # ------------------------------
    msg = f"[{event['severity']}] {src_ip} → {attack}"
    if reason:
        msg += f" | Correlated: {reason}"
    print(msg)


# ==============================
# START CAPTURE (STABLE LOOP)
# ==============================
def start_capture(interface=None):
    print("\n[+] SOC Packet Capture Running")
    print("[+] ML Detection ENABLED")
    print("[+] Correlation Engine ENABLED")
    print("[+] Auto-Response ENABLED")
    print("[+] Ctrl + C to stop\n")

    while True:
        try:
            sniff(
                iface=interface,
                prn=process_packet,
                store=False
            )
        except KeyboardInterrupt:
            print("\n[+] Capture stopped by user")
            break
        except Exception as e:
            print("[WARNING] Capture socket error, restarting...", e)
            time.sleep(2)
