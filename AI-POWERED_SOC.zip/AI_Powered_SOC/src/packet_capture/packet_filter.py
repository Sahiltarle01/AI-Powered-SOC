def is_suspicious(packet):
    if packet.haslayer("TCP"):
        if packet["TCP"].dport in [21, 22, 23, 3389]:
            return True
    return False
