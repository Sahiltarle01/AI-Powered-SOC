import sqlite3
import os
from datetime import datetime

DB_DIR = "database"
DB_PATH = os.path.join(DB_DIR, "soc.db")


def init_db():
    os.makedirs(DB_DIR, exist_ok=True)

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    # Traffic table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS traffic (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            verdict TEXT,
            attack_type TEXT,
            severity TEXT,
            src_ip TEXT,
            packet_summary TEXT
        )
    """)

    # Alerts table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            attack_type TEXT,
            severity TEXT,
            src_ip TEXT,
            packet_summary TEXT
        )
    """)

    # Response table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS response (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            action TEXT,
            src_ip TEXT
        )
    """)

    conn.commit()
    conn.close()


def insert_traffic(verdict, attack_type, severity, src_ip, packet_summary):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("""
        INSERT INTO traffic
        (timestamp, verdict, attack_type, severity, src_ip, packet_summary)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        datetime.now().isoformat(),
        verdict,
        attack_type,
        severity,
        src_ip,
        packet_summary
    ))

    conn.commit()
    conn.close()


def insert_alert(attack_type, severity, src_ip, packet_summary):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("""
        INSERT INTO alerts
        (timestamp, attack_type, severity, src_ip, packet_summary)
        VALUES (?, ?, ?, ?, ?)
    """, (
        datetime.now().isoformat(),
        attack_type,
        severity,
        src_ip,
        packet_summary
    ))

    conn.commit()
    conn.close()


def insert_response(action, src_ip):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("""
        INSERT INTO response
        (timestamp, action, src_ip)
        VALUES (?, ?, ?)
    """, (
        datetime.now().isoformat(),
        action,
        src_ip
    ))

    conn.commit()
    conn.close()
