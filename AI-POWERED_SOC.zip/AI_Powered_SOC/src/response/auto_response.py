from datetime import datetime
import os

LOG_DIR = "logs"
RESPONSE_LOG = os.path.join(LOG_DIR, "response.log")

# In-memory blocked IP list (simulation)
BLOCKED_IPS = set()


def extract_ip(packet_summary):
    """
    Extract source IP from packet summary string
    Example: Ether / IP / TCP 192.168.1.35:50324 > 44.205.104.6:https
    """
    try:
        parts = packet_summary.split()
        for part in parts:
            if part.count(".") == 3:
                return part.split(":")[0]
    except Exception:
        pass
    return "UNKNOWN"


def block_ip(ip):
    if ip in BLOCKED_IPS:
        return

    BLOCKED_IPS.add(ip)
    timestamp = datetime.now()

    entry = f"{timestamp} | BLOCKED IP (SIMULATED) | {ip}\n"
    with open(RESPONSE_LOG, "a", encoding="utf-8") as f:
        f.write(entry)

    print(">>> AUTO RESPONSE ACTIVATED <<<")
    print(f"Blocked IP : {ip}")
    print("Action     : Simulated firewall block")
    print(">>> ======================== <<<\n")
