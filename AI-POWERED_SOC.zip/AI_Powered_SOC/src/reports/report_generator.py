# src/reports/report_generator.py

import os
import sqlite3
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph
from reportlab.lib.units import inch

# =====================================================
# PATH CONFIG
# =====================================================
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
DB_PATH = os.path.join(BASE_DIR, "database", "soc_logs.db")
REPORT_DIR = os.path.join(BASE_DIR, "reports")

os.makedirs(REPORT_DIR, exist_ok=True)

# =====================================================
# DB HELPER
# =====================================================
def fetch_events(limit=200):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    cur.execute("""
        SELECT time, src_ip, attack, severity, protocol, dst_port, verdict, response
        FROM events
        ORDER BY time DESC
        LIMIT ?
    """, (limit,))

    rows = cur.fetchall()
    conn.close()
    return rows

# =====================================================
# MAIN PDF GENERATOR
# =====================================================
def generate_pdf(filters=None):
    """
    Generates a SOC Incident PDF Report
    Returns full file path
    """

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"SOC_Incident_Report_{timestamp}.pdf"
    path = os.path.join(REPORT_DIR, filename)

    c = canvas.Canvas(path, pagesize=A4)
    width, height = A4

    styles = getSampleStyleSheet()
    normal = styles["Normal"]

    y = height - 50

    # =================================================
    # TITLE PAGE
    # =================================================
    c.setFont("Helvetica-Bold", 20)
    c.drawCentredString(width / 2, y, "AI Powered SOC – Incident Report")
    y -= 40

    c.setFont("Helvetica", 11)
    c.drawString(50, y, f"Generated On : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    y -= 20
    c.drawString(50, y, "System       : AI Powered SOC")
    y -= 20
    c.drawString(50, y, "Report Type  : Security Incident Summary")
    y -= 40

    c.line(40, y, width - 40, y)
    y -= 30

    # =================================================
    # EXECUTIVE SUMMARY
    # =================================================
    c.setFont("Helvetica-Bold", 14)
    c.drawString(50, y, "1. Executive Summary")
    y -= 20

    summary_text = (
        "This report presents a consolidated view of security events detected by the "
        "AI Powered Security Operations Center. Events are analyzed using machine "
        "learning, correlated in real time, and enriched with automated response actions."
    )

    p = Paragraph(summary_text, normal)
    w, h = p.wrap(width - 100, y)
    p.drawOn(c, 50, y - h)
    y -= h + 20

    # =================================================
    # FETCH EVENTS
    # =================================================
    events = fetch_events()

    severity_count = {}
    attack_count = {}
    ip_count = {}

    for e in events:
        severity_count[e["severity"]] = severity_count.get(e["severity"], 0) + 1
        attack_count[e["attack"]] = attack_count.get(e["attack"], 0) + 1
        ip_count[e["src_ip"]] = ip_count.get(e["src_ip"], 0) + 1

    # =================================================
    # SEVERITY STATS
    # =================================================
    c.setFont("Helvetica-Bold", 14)
    c.drawString(50, y, "2. Severity Distribution")
    y -= 20

    c.setFont("Helvetica", 11)
    for sev, cnt in severity_count.items():
        c.drawString(70, y, f"{sev} : {cnt} events")
        y -= 15

    y -= 20

    # =================================================
    # TOP ATTACK TYPES
    # =================================================
    c.setFont("Helvetica-Bold", 14)
    c.drawString(50, y, "3. Attack Type Summary")
    y -= 20

    c.setFont("Helvetica", 11)
    for atk, cnt in attack_count.items():
        c.drawString(70, y, f"{atk} : {cnt} events")
        y -= 15

    y -= 20

    # =================================================
    # TOP SOURCE IPs
    # =================================================
    c.setFont("Helvetica-Bold", 14)
    c.drawString(50, y, "4. Top Source IPs")
    y -= 20

    c.setFont("Helvetica", 11)
    for ip, cnt in sorted(ip_count.items(), key=lambda x: x[1], reverse=True)[:5]:
        c.drawString(70, y, f"{ip} : {cnt} events")
        y -= 15

    # =================================================
    # NEW PAGE – EVENT LOGS
    # =================================================
    c.showPage()
    y = height - 50

    c.setFont("Helvetica-Bold", 14)
    c.drawString(50, y, "5. Detailed Event Log")
    y -= 25

    c.setFont("Helvetica", 9)

    for e in events:
        line = (
            f"[{e['time']}] "
            f"{e['src_ip']} | "
            f"{e['attack']} | "
            f"{e['severity']} | "
            f"{e['protocol']}:{e['dst_port']} | "
            f"{e['verdict']} | "
            f"{e['response'] or 'NONE'}"
        )

        c.drawString(50, y, line[:110])

        y -= 12
        if y < 50:
            c.showPage()
            y = height - 50
            c.setFont("Helvetica", 9)

    # =================================================
    # FOOTER
    # =================================================
    c.showPage()
    c.setFont("Helvetica-Oblique", 10)
    c.drawCentredString(
        width / 2,
        30,
        "Generated by AI Powered SOC – Automated Security Intelligence System"
    )

    c.save()
    return path
