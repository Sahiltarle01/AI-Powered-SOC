import os
import json
from datetime import datetime
from fpdf import FPDF

BASE_DIR = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "..")
)

LOG_FILE = os.path.join(BASE_DIR, "logs", "traffic_logs.json")
REPORT_DIR = os.path.join(BASE_DIR, "reports")

os.makedirs(REPORT_DIR, exist_ok=True)


class SOCReport(FPDF):
    def header(self):
        self.set_font("Arial", "B", 14)
        self.cell(0, 10, "AI Powered SOC - Incident Report", ln=True, align="C")
        self.ln(5)

    def footer(self):
        self.set_y(-15)
        self.set_font("Arial", "I", 8)
        self.cell(
            0, 10,
            f"Generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            align="C"
        )


def generate_incident_report():
    if not os.path.exists(LOG_FILE):
        return None

    with open(LOG_FILE, "r", encoding="utf-8") as f:
        logs = json.load(f)

    if not logs:
        return None

    pdf = SOCReport()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()
    pdf.set_font("Arial", size=10)

    severity_count = {}

    for log in logs:
        sev = log.get("severity", "UNKNOWN")
        severity_count[sev] = severity_count.get(sev, 0) + 1

        pdf.multi_cell(
            0, 8,
            f"""
Time      : {log.get('time')}
Source IP: {log.get('src_ip')}
Attack   : {log.get('attack')}
Severity : {sev}
Protocol : {log.get('protocol')}
Port     : {log.get('dst_port')}
Verdict  : {log.get('verdict')}
Response : {log.get('response')}
--------------------------------------------
"""
        )

    # Summary Page
    pdf.add_page()
    pdf.set_font("Arial", "B", 12)
    pdf.cell(0, 10, "Incident Summary", ln=True)

    pdf.set_font("Arial", size=11)
    for sev, count in severity_count.items():
        pdf.cell(0, 8, f"{sev}: {count}", ln=True)

    filename = f"SOC_Incident_Report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    report_path = os.path.join(REPORT_DIR, filename)

    pdf.output(report_path)

    return report_path
