# src/correlation/engine.py

from collections import defaultdict
from datetime import datetime, timedelta
from src.alerts.notifier import send_critical_alert

# =====================================================
# CONFIG (UPGRADABLE – SOC RULES)
# =====================================================
TIME_WINDOW_MINUTES = 5          # Correlation window
REPEAT_THRESHOLD = 3             # Same attack repetition
MULTI_ATTACK_THRESHOLD = 2       # Different attack types
HIGH_SEVERITY_THRESHOLD = 2      # Multiple HIGH events

# =====================================================
# IN-MEMORY STORE
# =====================================================
# {
#   "ip": [
#       {
#           "attack": str,
#           "severity": str,
#           "time": datetime
#       }
#   ]
# }
attack_history = defaultdict(list)

# =====================================================
# SEVERITY ORDER
# =====================================================
SEVERITY_RANK = {
    "LOW": 1,
    "MEDIUM": 2,
    "HIGH": 3,
    "CRITICAL": 4
}

# =====================================================
# MAIN CORRELATION FUNCTION
# =====================================================
def correlate_event(event: dict):
    """
    Takes a single event dict and returns:
    (final_severity, correlation_reason)

    event = {
        "src_ip": str,
        "attack": str,
        "severity": str
    }
    """

    src_ip = event.get("src_ip")
    attack = event.get("attack")
    severity = event.get("severity", "LOW")
    now = datetime.now()

    # ------------------------------
    # Store event
    # ------------------------------
    attack_history[src_ip].append({
        "attack": attack,
        "severity": severity,
        "time": now
    })

    # ------------------------------
    # Cleanup old events
    # ------------------------------
    cutoff = now - timedelta(minutes=TIME_WINDOW_MINUTES)
    attack_history[src_ip] = [
        e for e in attack_history[src_ip]
        if e["time"] >= cutoff
    ]

    events = attack_history[src_ip]

    # ------------------------------
    # RULE 1: Multiple attack types
    # ------------------------------
    unique_attacks = set(e["attack"] for e in events)
    if len(unique_attacks) >= MULTI_ATTACK_THRESHOLD:
        final_severity = "CRITICAL"
        reason = f"Multiple attack types detected: {', '.join(unique_attacks)}"
        _trigger_alert(src_ip, reason)
        return final_severity, reason

    # ------------------------------
    # RULE 2: Repeated same attack
    # ------------------------------
    same_attack_count = sum(1 for e in events if e["attack"] == attack)
    if same_attack_count >= REPEAT_THRESHOLD:
        final_severity = escalate_severity(severity)
        reason = f"Repeated attack pattern ({same_attack_count} times)"
        if final_severity == "CRITICAL":
            _trigger_alert(src_ip, reason)
        return final_severity, reason

    # ------------------------------
    # RULE 3: Multiple HIGH severity events
    # ------------------------------
    high_count = sum(1 for e in events if e["severity"] == "HIGH")
    if high_count >= HIGH_SEVERITY_THRESHOLD:
        final_severity = "CRITICAL"
        reason = "Multiple HIGH severity events correlated"
        _trigger_alert(src_ip, reason)
        return final_severity, reason

    # ------------------------------
    # DEFAULT: No escalation
    # ------------------------------
    return severity, None

# =====================================================
# SEVERITY ESCALATION
# =====================================================
def escalate_severity(current: str) -> str:
    if current not in SEVERITY_RANK:
        return current

    if current == "LOW":
        return "MEDIUM"
    if current == "MEDIUM":
        return "HIGH"
    if current == "HIGH":
        return "CRITICAL"

    return "CRITICAL"

# =====================================================
# ALERT TRIGGER (CRITICAL ONLY)
# =====================================================
def _trigger_alert(src_ip: str, reason: str):
    """
    Central place to trigger CRITICAL alerts
    """
    send_critical_alert(
        src_ip=src_ip,
        attack="Correlated Attack",
        severity="CRITICAL"
    )
