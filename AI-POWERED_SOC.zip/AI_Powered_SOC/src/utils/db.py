import sqlite3
import os

BASE_DIR = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "..")
)

DB_PATH = os.path.join(BASE_DIR, "database", "soc_logs.db")
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)


def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            time TEXT,
            src_ip TEXT,
            attack TEXT,
            severity TEXT,
            protocol TEXT,
            dst_port INTEGER,
            verdict TEXT,
            response TEXT
        )
    """)

    conn.commit()
    conn.close()


def insert_event(event):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("""
        INSERT INTO events
        (time, src_ip, attack, severity, protocol, dst_port, verdict, response)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        event["time"],
        event["src_ip"],
        event["attack"],
        event["severity"],
        event["protocol"],
        event["dst_port"],
        event["verdict"],
        event["response"]
    ))

    conn.commit()
    conn.close()


def fetch_recent(limit=50):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("""
        SELECT time, src_ip, attack, severity, protocol, dst_port, verdict, response
        FROM events
        ORDER BY id DESC
        LIMIT ?
    """, (limit,))

    rows = cur.fetchall()
    conn.close()

    return rows
