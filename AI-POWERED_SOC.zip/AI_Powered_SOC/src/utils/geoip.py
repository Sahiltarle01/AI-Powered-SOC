# src/utils/geoip.py
import requests
import ipaddress

# Free Geo-IP API (safe for demo & college)
GEO_API = "http://ip-api.com/json/{}"


def is_private_ip(ip: str) -> bool:
    """
    Check if IP is private / local
    """
    try:
        return ipaddress.ip_address(ip).is_private
    except ValueError:
        return True


def get_geo_ip(ip: str):
    """
    Returns geo info for an IP

    Output:
    {
        country,
        country_code,
        city,
        isp,
        lat,
        lon
    }
    """

    # Skip private / invalid IPs
    if is_private_ip(ip):
        return None

    try:
        resp = requests.get(
            GEO_API.format(ip),
            timeout=5
        )

        # API failure safety
        if resp.status_code != 200:
            return None

        data = resp.json()

        if data.get("status") != "success":
            return None

        return {
            "country": data.get("country", "Unknown"),
            "country_code": data.get("countryCode", "XX"),
            "city": data.get("city", "Unknown"),
            "isp": data.get("isp", "Unknown"),
            "lat": data.get("lat"),
            "lon": data.get("lon")
        }

    except Exception:
        return None
