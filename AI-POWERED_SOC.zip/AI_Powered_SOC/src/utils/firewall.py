import os
import json
import platform
import subprocess
from datetime import datetime

BASE_DIR = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "..")
)

BLOCK_LOG = os.path.join(BASE_DIR, "logs", "blocked_ips.json")
os.makedirs(os.path.dirname(BLOCK_LOG), exist_ok=True)

# Initialize block log
if not os.path.exists(BLOCK_LOG):
    with open(BLOCK_LOG, "w") as f:
        json.dump([], f)


def log_block(ip, method):
    with open(BLOCK_LOG, "r+") as f:
        data = json.load(f)
        data.append({
            "ip": ip,
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "method": method
        })
        f.seek(0)
        json.dump(data, f, indent=2)


# ================= WINDOWS FIREWALL =================
def block_ip_windows(ip):
    rule_name = f"SOC_Block_{ip}"
    cmd = [
        "netsh", "advfirewall", "firewall", "add", "rule",
        f"name={rule_name}",
        "dir=in",
        "action=block",
        f"remoteip={ip}"
    ]

    subprocess.run(cmd, capture_output=True)
    log_block(ip, "Windows Firewall")


# ================= LINUX IPTABLES =================
def block_ip_linux(ip):
    subprocess.run(
        ["iptables", "-A", "INPUT", "-s", ip, "-j", "DROP"],
        capture_output=True
    )
    log_block(ip, "iptables")


# ================= AUTO DETECT =================
def block_ip(ip):
    system = platform.system().lower()

    if "windows" in system:
        block_ip_windows(ip)
        return "Windows Firewall"

    elif "linux" in system:
        block_ip_linux(ip)
        return "iptables"

    else:
        return "Unsupported OS"
