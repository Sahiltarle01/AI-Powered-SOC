import smtplib
import yaml
import requests
import os
import time
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime

# ==============================
# CONFIG PATH
# ==============================
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
CONFIG_PATH = os.path.join(BASE_DIR, "configs", "alert_config.yaml")

# ==============================
# RATE LIMIT MEMORY
# ==============================
LAST_ALERT_TIME = {}

# ==============================
# LOAD CONFIG
# ==============================
def load_config():
    if not os.path.exists(CONFIG_PATH):
        raise FileNotFoundError(f"Alert config not found: {CONFIG_PATH}")

    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

# ==============================
# RATE LIMIT CHECK
# ==============================
def is_rate_limited(src_ip: str, cooldown: int) -> bool:
    now = time.time()
    last = LAST_ALERT_TIME.get(src_ip, 0)

    if now - last < cooldown:
        return True

    LAST_ALERT_TIME[src_ip] = now
    return False

# ==============================
# EMAIL ALERT
# ==============================
def send_email(subject: str, body: str, cfg: dict):
    try:
        msg = MIMEMultipart()
        msg["From"] = cfg["sender_email"]
        msg["To"] = cfg["receiver_email"]
        msg["Subject"] = subject
        msg.attach(MIMEText(body, "plain"))

        server = smtplib.SMTP(cfg["smtp_server"], cfg["smtp_port"], timeout=10)
        server.starttls()
        server.login(cfg["sender_email"], cfg["sender_password"])
        server.send_message(msg)
        server.quit()

        print("[ALERT] Email sent")

    except Exception as e:
        print(f"[ALERT][EMAIL ERROR] {e}")

# ==============================
# TELEGRAM ALERT
# ==============================
def send_telegram(message: str, cfg: dict):
    try:
        url = f"https://api.telegram.org/bot{cfg['bot_token']}/sendMessage"
        payload = {
            "chat_id": cfg["chat_id"],
            "text": message,
            "parse_mode": "Markdown"
        }

        res = requests.post(url, json=payload, timeout=10)

        if res.status_code == 200:
            print("[ALERT] Telegram sent")
        else:
            print(f"[ALERT][TELEGRAM ERROR] {res.text}")

    except Exception as e:
        print(f"[ALERT][TELEGRAM ERROR] {e}")

# ==============================
# MAIN ENTRY – CRITICAL ALERT
# ==============================
def send_critical_alert(src_ip: str, attack: str, severity: str):
    """
    SOC Critical Alert
    Called from capture / correlation engine
    """

    if severity != "CRITICAL":
        return  # only CRITICAL alerts

    cfg = load_config()

    # Rate limit
    rate_cfg = cfg.get("rate_limit", {})
    if rate_cfg.get("enabled", False):
        cooldown = rate_cfg.get("cooldown_seconds", 300)
        if is_rate_limited(src_ip, cooldown):
            print("[ALERT] Rate limited – skipping alert")
            return

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    message = f"""
🚨 *CRITICAL SECURITY ALERT* 🚨

🕒 Time: {timestamp}
🌐 Source IP: {src_ip}
⚠️ Attack Type: {attack}
🔥 Severity: {severity}

🛡️ Action: Auto-response triggered
🤖 System: AI Powered SOC
"""

    subject = "🚨 CRITICAL SOC ALERT"

    # Send Email
    if cfg.get("email", {}).get("enabled", False):
        send_email(subject, message, cfg["email"])

    # Send Telegram
    if cfg.get("telegram", {}).get("enabled", False):
        send_telegram(message, cfg["telegram"])
