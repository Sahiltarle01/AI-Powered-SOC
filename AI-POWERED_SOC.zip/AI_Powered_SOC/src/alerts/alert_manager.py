from datetime import datetime
import os

LOG_DIR = "logs"
ALERT_LOG = os.path.join(LOG_DIR, "alerts.log")
TRAFFIC_LOG = os.path.join(LOG_DIR, "traffic.log")

def log_traffic(packet_summary, verdict, attack_type="NORMAL", severity="LOW"):
    ts = datetime.now()
    entry = f"{ts} | {verdict} | {attack_type} | {severity} | {packet_summary}\n"
    with open(TRAFFIC_LOG, "a", encoding="utf-8") as f:
        f.write(entry)

def raise_alert(packet_summary, attack_type, severity):
    ts = datetime.now()
    entry = f"{ts} | {attack_type} | {severity} | {packet_summary}\n"
    with open(ALERT_LOG, "a", encoding="utf-8") as f:
        f.write(entry)

    print("\n========== SOC ALERT ==========")
    print(f"Time     : {ts}")
    print(f"Type     : {attack_type}")
    print(f"Severity : {severity}")
    print(f"Packet   : {packet_summary}")
    print("================================\n")
