import time
import yaml
import requests
import os
import ipaddress

from src.utils.firewall import block_ip

BASE_DIR = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "..")
)

CONFIG_PATH = os.path.join(BASE_DIR, "configs", "alert_config.yaml")


def load_config():
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def send_message(token, chat_id, text):
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": text
    }
    requests.post(url, json=payload, timeout=10)


def is_valid_ip(ip):
    try:
        ipaddress.ip_address(ip)
        return True
    except Exception:
        return False


# ==================================================
# TELEGRAM COMMAND LISTENER
# ==================================================
def start_status_listener():
    cfg = load_config()["telegram"]

    if not cfg.get("enabled", False):
        print("[TELEGRAM] Disabled in config")
        return

    token = cfg["bot_token"]
    admin_chat_id = str(cfg["chat_id"])

    print("[TELEGRAM] Command listener started")

    last_update_id = None

    while True:
        try:
            url = f"https://api.telegram.org/bot{token}/getUpdates"
            if last_update_id:
                url += f"?offset={last_update_id + 1}"

            r = requests.get(url, timeout=15).json()

            for update in r.get("result", []):
                last_update_id = update["update_id"]

                if "message" not in update:
                    continue

                msg = update["message"]
                chat_id = str(msg["chat"]["id"])
                text = msg.get("text", "").strip()

                # 🔐 Only ADMIN chat allowed
                if chat_id != admin_chat_id:
                    send_message(token, chat_id, "❌ Unauthorized")
                    continue

                # ---------------- /block ----------------
                if text.startswith("/block"):
                    parts = text.split()
                    if len(parts) != 2:
                        send_message(
                            token, chat_id,
                            "Usage: /block <IP_ADDRESS>"
                        )
                        continue

                    ip = parts[1]

                    if not is_valid_ip(ip):
                        send_message(token, chat_id, "❌ Invalid IP address")
                        continue

                    method = block_ip(ip)
                    send_message(
                        token, chat_id,
                        f"🚫 IP BLOCKED\n\nIP: {ip}\nMethod: {method}"
                    )

                # ---------------- /status ----------------
                elif text == "/status":
                    send_message(
                        token, chat_id,
                        "🛡️ AI Powered SOC\nStatus: RUNNING\nAll systems operational"
                    )

                # ---------------- HELP ----------------
                elif text == "/help":
                    send_message(
                        token, chat_id,
                        "/status – SOC status\n"
                        "/block <ip> – Block IP\n"
                        "/help – Commands"
                    )

        except Exception as e:
            print("[TELEGRAM ERROR]", e)

        time.sleep(3)
