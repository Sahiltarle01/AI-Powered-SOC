from datetime import datetime
from scapy.layers.inet import IP
import random

def predict_packet(packet):
    src_ip = packet[IP].src
    attack_types = ["Port Scan", "DDoS", "Brute Force", "Normal"]
    severities = ["LOW", "MEDIUM", "HIGH", "CRITICAL"]

    attack = random.choice(attack_types)
    severity = random.choice(severities)

    return {
        "time": datetime.now().strftime("%H:%M:%S"),
        "src_ip": src_ip,
        "attack": attack,
        "severity": severity
    }
