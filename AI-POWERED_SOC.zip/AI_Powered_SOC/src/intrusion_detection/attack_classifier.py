def classify_attack(features):
    """
    features order:
    [pkt_len, is_tcp, is_udp, is_icmp, pps, src_ip_count, dst_port_count, burst_score]
    """
    pkt_len, is_tcp, is_udp, is_icmp, pps, src_ip_count, dst_port_count, burst = features

    # Default
    attack_type = "NORMAL"
    severity = "LOW"

    # Attack type rules
    if is_icmp and pps > 10:
        attack_type = "ICMP_FLOOD"
    elif is_tcp and dst_port_count > 10:
        attack_type = "PORT_SCAN"
    elif is_tcp and burst == 1 and pps > 15:
        attack_type = "TCP_FLOOD"

    # Severity scoring
    score = 0
    score += 2 if pps > 20 else 1 if pps > 10 else 0
    score += 2 if burst == 1 else 0
    score += 2 if dst_port_count > 20 else 1 if dst_port_count > 10 else 0

    if score >= 5:
        severity = "CRITICAL"
    elif score >= 3:
        severity = "HIGH"
    elif score >= 1:
        severity = "MEDIUM"
    else:
        severity = "LOW"

    return attack_type, severity
