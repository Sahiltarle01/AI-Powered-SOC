import time
from collections import defaultdict

# State memory (behavior tracking)
packet_times = []
src_ip_counter = defaultdict(int)
dst_port_counter = defaultdict(set)

WINDOW = 5  # seconds


def extract_features(packet):
    now = time.time()
    packet_times.append(now)

    # Time window cleanup
    while packet_times and packet_times[0] < now - WINDOW:
        packet_times.pop(0)

    pps = len(packet_times) / WINDOW

    # Protocol flags
    is_tcp = int(packet.haslayer("TCP"))
    is_udp = int(packet.haslayer("UDP"))
    is_icmp = int(packet.haslayer("ICMP"))

    pkt_len = len(packet)

    # Source IP tracking
    src_ip = packet["IP"].src if packet.haslayer("IP") else "0.0.0.0"
    src_ip_counter[src_ip] += 1
    src_ip_count = src_ip_counter[src_ip]

    # Destination port diversity
    if is_tcp:
        dst_port = packet["TCP"].dport
        dst_port_counter[src_ip].add(dst_port)
    dst_port_count = len(dst_port_counter[src_ip])

    # Burst detection
    burst_score = 1 if pps > 10 else 0

    return [
        pkt_len,
        is_tcp,
        is_udp,
        is_icmp,
        pps,
        src_ip_count,
        dst_port_count,
        burst_score
    ]
