import socket
import time

TARGET = "127.0.0.1"
PORTS = [22, 80, 443]

print("[*] Simulating attack traffic...")

for _ in range(3):
    for port in PORTS:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(1)
            s.connect((TARGET, port))
        except:
            pass
        finally:
            s.close()
        time.sleep(0.5)

print("[+] Attack simulation complete")
