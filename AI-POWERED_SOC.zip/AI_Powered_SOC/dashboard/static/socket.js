const socket = io();

socket.on("connect", () => {
    console.log("WebSocket connected");
});

socket.on("update_dashboard", data => {
    console.log("LIVE EVENT:", data);

    // Append log
    const logBox = document.getElementById("liveLogs");
    if (logBox) {
        logBox.textContent += JSON.stringify(data) + "\n";
        logBox.scrollTop = logBox.scrollHeight;
    }

    // Future:
    // updateCharts(data);
    // updateGeoMap(data);
});
