from flask import (
    Flask, render_template, request, redirect,
    url_for, session, jsonify, send_file
)
from functools import wraps
import os
import sqlite3
import hashlib
from datetime import datetime, timedelta

# =====================================================
# APP CONFIG
# =====================================================
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DB_PATH = os.path.join(BASE_DIR, "database", "soc_logs.db")
REPORT_DIR = os.path.join(BASE_DIR, "reports")

app = Flask(__name__)
app.secret_key = "AI_POWERED_SOC_SECRET_KEY"
app.permanent_session_lifetime = timedelta(hours=8)

os.makedirs(REPORT_DIR, exist_ok=True)

# =====================================================
# CONSTANTS
# =====================================================
SEVERITY_COLOR = {
    "CRITICAL": "red",
    "HIGH": "orange",
    "MEDIUM": "yellow",
    "LOW": "green"
}

# =====================================================
# DB HELPERS
# =====================================================
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def init_user_table():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT,
            role TEXT
        )
    """)
    conn.commit()
    conn.close()

init_user_table()

# =====================================================
# AUTH DECORATORS
# =====================================================
def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper

def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if session.get("role") != "admin":
            return "Unauthorized", 403
        return f(*args, **kwargs)
    return wrapper

# =====================================================
# LOGIN / LOGOUT (REAL USER DB)
# =====================================================
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = request.form.get("username")
        p = request.form.get("password")

        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE username=?", (u,))
        user = cur.fetchone()
        conn.close()

        if user and user["password"] == hash_password(p):
            session.permanent = True
            session["logged_in"] = True
            session["user"] = user["username"]
            session["role"] = user["role"]
            return redirect(url_for("dashboard"))

        return render_template("login.html", error="Invalid credentials")

    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

# =====================================================
# DASHBOARD
# =====================================================
@app.route("/")
@login_required
def dashboard():
    return render_template(
        "index.html",
        heatmap_data=get_geo_heatmap(),
        timeline_data=get_attack_timeline(),
        severity_data=get_severity_counts(),
        attack_data=get_attack_types(),
        top_ips=get_top_ips(),
        role=session.get("role")
    )

# =====================================================
# USER MANAGEMENT (ADMIN ONLY)
# =====================================================
@app.route("/admin/users", methods=["GET", "POST"])
@login_required
@admin_required
def manage_users():
    conn = get_db()
    cur = conn.cursor()

    if request.method == "POST":
        cur.execute(
            "INSERT INTO users (username,password,role) VALUES (?,?,?)",
            (
                request.form["username"],
                hash_password(request.form["password"]),
                request.form["role"]
            )
        )
        conn.commit()

    cur.execute("SELECT id, username, role FROM users")
    users = cur.fetchall()
    conn.close()

    return render_template("users.html", users=users)

@app.route("/admin/users/delete/<int:uid>")
@login_required
@admin_required
def delete_user(uid):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("DELETE FROM users WHERE id=?", (uid,))
    conn.commit()
    conn.close()
    return redirect(url_for("manage_users"))

# =====================================================
# API ENDPOINTS
# =====================================================
@app.route("/api/heatmap")
@login_required
def api_heatmap():
    return jsonify(get_geo_heatmap())

@app.route("/api/timeline")
@login_required
def api_timeline():
    return jsonify(get_attack_timeline())

@app.route("/api/severity")
@login_required
def api_severity():
    return jsonify(get_severity_counts())

@app.route("/api/attack-types")
@login_required
def api_attack_types():
    return jsonify(get_attack_types())

@app.route("/api/top-ips")
@login_required
def api_top_ips():
    return jsonify(get_top_ips())

# =====================================================
# DATA FETCH FUNCTIONS
# =====================================================
def get_geo_heatmap():
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("""
            SELECT latitude, longitude, severity, COUNT(*) AS count
            FROM events
            WHERE latitude IS NOT NULL
            GROUP BY latitude, longitude, severity
        """)
        rows = cur.fetchall()
        conn.close()
    except:
        rows = []

    return [{
        "lat": r["latitude"],
        "lon": r["longitude"],
        "severity": r["severity"],
        "count": r["count"],
        "color": SEVERITY_COLOR.get(r["severity"], "blue")
    } for r in rows]

def get_attack_timeline():
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("""
            SELECT substr(time,1,16) AS time, COUNT(*) AS count
            FROM events
            GROUP BY substr(time,1,16)
            ORDER BY time
        """)
        rows = cur.fetchall()
        conn.close()
    except:
        rows = []

    return [{"time": r["time"], "count": r["count"]} for r in rows]

def get_severity_counts():
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT severity, COUNT(*) AS count FROM events GROUP BY severity")
        rows = cur.fetchall()
        conn.close()
    except:
        rows = []

    return {r["severity"]: r["count"] for r in rows}

def get_attack_types():
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT attack, COUNT(*) AS count FROM events GROUP BY attack")
        rows = cur.fetchall()
        conn.close()
    except:
        rows = []

    return {r["attack"]: r["count"] for r in rows}

def get_top_ips():
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("""
            SELECT src_ip, COUNT(*) AS count
            FROM events
            GROUP BY src_ip
            ORDER BY count DESC
            LIMIT 5
        """)
        rows = cur.fetchall()
        conn.close()
    except:
        rows = []

    return [{"ip": r["src_ip"], "count": r["count"]} for r in rows]

# =====================================================
# REPORT DOWNLOAD
# =====================================================
@app.route("/download/report")
@login_required
@admin_required
def download_report():
    from src.reports.report_generator import generate_pdf
    path = generate_pdf({})
    return send_file(path, as_attachment=True)

# =====================================================
# HEALTH CHECK
# =====================================================
@app.route("/health")
def health():
    return jsonify({"status": "OK", "time": datetime.now().isoformat()})

# =====================================================
# START SERVER
# =====================================================
if __name__ == "__main__":
    print("[+] AI Powered SOC Dashboard starting...")
    app.run(host="0.0.0.0", port=5000, debug=False)
