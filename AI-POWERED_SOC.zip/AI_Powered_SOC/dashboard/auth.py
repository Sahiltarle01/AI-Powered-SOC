from werkzeug.security import generate_password_hash, check_password_hash

# Demo users (can be moved to DB later)
USERS = {
    "admin": {
        "password": generate_password_hash("admin123"),
        "role": "ADMIN"
    },
    "analyst": {
        "password": generate_password_hash("analyst123"),
        "role": "ANALYST"
    }
}

def authenticate(username, password):
    user = USERS.get(username)
    if not user:
        return None

    if check_password_hash(user["password"], password):
        return user["role"]

    return None
