from flask import Flask
from flask_socketio import SocketIO, emit
import json
import os

app = Flask(__name__)
app.config["SECRET_KEY"] = "SOC_SOCKET_SECRET"

socketio = SocketIO(app, cors_allowed_origins="*")

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
LOG_PATH = os.path.join(BASE_DIR, "database", "soc_logs.db")


@app.route("/")
def index():
    return "<h3>AI Powered SOC WebSocket Server Running</h3>"


@socketio.on("connect")
def handle_connect():
    print("[SOCKET] Client connected")


@socketio.on("disconnect")
def handle_disconnect():
    print("[SOCKET] Client disconnected")


def broadcast_new_event(event):
    socketio.emit("new_event", event)


if __name__ == "__main__":
    socketio.run(app, host="0.0.0.0", port=5001, debug=True)
