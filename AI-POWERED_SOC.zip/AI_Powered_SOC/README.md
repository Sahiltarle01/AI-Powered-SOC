# AI-Powered SOC System

An advanced cybersecurity project that detects network intrusions using
Machine Learning and performs automated incident response.

## Features
- Network traffic monitoring
- ML-based intrusion detection
- Severity scoring
- Alert & logging system
- SOC dashboard

## Tech Stack
- Python
- Scapy
- Machine Learning
- Flask
- HTML/CSS/JS

## How to Run
```bash
pip install -r requirements.txt
python main.py
