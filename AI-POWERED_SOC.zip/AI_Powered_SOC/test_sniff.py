from scapy.all import sniff

def pkt(pkt):
    print("PACKET >>>", pkt.summary())

print("Starting basic sniff...")
sniff(prn=pkt, store=False)
